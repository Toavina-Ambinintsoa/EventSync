import {prisma} from "../lib/prisma.js"

export function create_event(event : Event){
    return prisma.event.create({event})
}