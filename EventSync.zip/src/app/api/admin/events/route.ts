export async function POST(request: Request) {
    const {
        id, title, description, startDate, endDate, location
    } = await request.json();

    
}