import type { Event } from "../schema/Event";

export function create_event(event : Event){

}